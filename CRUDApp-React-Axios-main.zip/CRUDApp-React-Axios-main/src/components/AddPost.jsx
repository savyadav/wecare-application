import React from 'react'

const AddPost = () => {
  return (
    <div>AddPost</div>
  )
}

export default AddPost